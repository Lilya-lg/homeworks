package MoneyManager;

import java.io.FileInputStream;

public class User {
	private String name;
	private double totalAmount;
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public void setTotalAmountWithIncome(double sum) {
		this.totalAmount = totalAmount+sum;
	}
	public void setTotalAmountWithOutcome(double sum) {
		this.totalAmount = totalAmount-sum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	private String gender;
	public User(String name, String gender,double totalAmount) {
		super();
		this.name = name;
		this.gender = gender;
		this.totalAmount = totalAmount;
	} 
}
