package MoneyManager;

public class MoneyTransactions {
	private String category;
	private double totalAmount;
	User user;
	public MoneyTransactions(String category, String transType, double sum,User user) {
		super();
		this.category = category;
		TransType = transType;
		this.sum = sum;
		this.user = user;
		if(transType == "Income") {
			calculateSumWithIncome();
		}
		else {
			calculateSumWithOutcome();
		}
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTransType() {
		return TransType;
	}
	public void setTransType(String transType) {
		TransType = transType;
	}
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	private String TransType;
	private double sum;
	public void calculateSumWithIncome() {
		user.setTotalAmountWithIncome(sum);
	}
	public void calculateSumWithOutcome() {
		user.setTotalAmountWithOutcome(sum);
	}
}
