package MoneyManager;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class MoneyFrame extends JFrame{
	DBConnector db_conn = new DBConnector();
	private JButton toCircleFrame = new JButton("Circle");
	private JButton toRectangleFrame = new JButton("Rectangle");
	private JButton buttonLogin = new JButton("Login");
	private JButton buttonSubmit = new JButton("Submit");
	private JButton buttonRegister = new JButton("Register");
	private JButton SvLdbutton = new JButton("Save/Load to base");
	private JButton toMainFrame = new JButton("Back");;
	private JButton toUserFrame = new JButton("Back");;
	private JButton NewTransaction = new JButton("New transaction");
	private JButton ShowHistory = new JButton("Show history");
	private JButton LoadBase = new JButton("Load from base");
	private JButton SaveBase = new JButton("Save to base");
	private JButton SaveUser = new JButton("Save");
	private JButton AddTrans = new JButton("Save");
	private  JButton  btnOpenDir = new JButton("Open directory"); ;
	private JLabel label = new JLabel("Your name: ");
	private JLabel labelAmount;
	private JLabel labelName;
	private JLabel labelGender;
	private JLabel category;
	private JLabel newSum;
	private JTextField fieldSearchName; 
	private JTextField fieldName;
	private JTextField fieldGender;
	private  JFileChooser fileChooser;
	private FileInputStream input;
	private File f;

	private JTextField fieldAmount;
	private JTextField inputCategory;
	 String[] items = {
	            "Income",
	            "Outcome"
	        };
	private JComboBox<String> comboBox = new JComboBox<>(items);
	private JPanel panel;
	private JTable table;
	private User user;
    //Shape[] shapes = new Shape[10];
	JLabel result = new JLabel("");
	
	public  MoneyFrame() {
		super("Money manager V1.0");
		setVisible(true);	
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(300,300);
		//label = new JLabel("Your name: ");
		panel = mainFrame();
		add(panel);
		setVisible(true);
		initListener();
	}
	public JPanel mainFrame() {
		label = new JLabel("Your name: ");
		fieldSearchName = new JTextField(" ",10);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(4,1,2,2));
		panel.add(label);
		panel.add(fieldSearchName);
		panel.add(buttonLogin);
		panel.add(buttonRegister);
		//panel.add(button3);
		//panel.add(SvLdbutton);	
		return panel;
	}
	
	public JPanel UserFrame() throws IOException {
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(6,1,2,2));
		labelAmount = new JLabel("Total amount: ");
		panel.add(labelAmount);
		try {
			double totalAmount = db_conn.getTotalAmount(user.getName());
			result.setText(String.valueOf(totalAmount));
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			 f = db_conn.getImage(user.getName());
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | FileNotFoundException
				| SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Image img = ImageIO.read(f);
		
		panel.add(result);
		if(img != null) {
			JLabel j1 = new JLabel(new ImageIcon(img.getScaledInstance(80, 50, Image.SCALE_DEFAULT)));
			panel.add(j1);
		}
		panel.add(NewTransaction);
		panel.add(ShowHistory);
		panel.add(toMainFrame);
		return panel;
		
	}
	public JPanel TransactionFrame() {
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(7,1,2,2));
		category = new JLabel("Enter category:");
		inputCategory = new JTextField();
		fieldAmount = new JTextField();
		newSum = new JLabel("Please insert the sum");
		panel.add(comboBox);
		panel.add(category);
		panel.add(inputCategory);
		panel.add(newSum);
		panel.add(fieldAmount);
		panel.add(AddTrans);
		panel.add(toUserFrame);
		return panel;
		
	}
	public JPanel HistoryFrame()  {
		String n = "",e = "";   
		Double d;
		JPanel panel = new JPanel();
		//DefaultTableModel model = (DefaultTableModel) table.getModel();
		DefaultTableModel model;
		model = new DefaultTableModel(); 
		table = new  JTable(model);

		model.addColumn("Category");
		model.addColumn("Type");
		model.addColumn("Amount");
		ResultSet rs;
		try {
			rs = db_conn.getHistory(user.getName());
			while(rs.next())
			{ 
			    n = rs.getString("category");
			    e= rs.getString("transType");
			    d = rs.getDouble("amount");
			    //Object[][]data={{n,e}};
			    // This will add row from the DB as the last row in the JTable. 
			    model.insertRow(table.getRowCount(), new Object[] {n, e, d});
			}
			rs.close();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		       
		panel.add(table);
		panel.add(toUserFrame);
		
		return panel;
		
	}
	public JPanel RegisterFrame() {
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(6,1,2,2));
		labelName = new JLabel("Please type your name: ");
		fieldName = new JTextField();
	  //  btnOpenDir = new JButton("Open directory");
		labelGender = new JLabel("Please type your gender: ");
		fieldGender = new JTextField();
	    fileChooser = new JFileChooser();
	   // addFileChooserListeners();
		panel.add(labelName);
		panel.add(fieldName);
		panel.add(labelGender);
		panel.add(fieldGender);
		panel.add(btnOpenDir);
		panel.add(SaveUser);
		//panel.add(toMainFrame);
		return panel;
		
	}
	
	public JPanel DatabaseFrame() {
		JPanel panel = new JPanel();
		panel.add(LoadBase);
		panel.add(SaveBase);
		panel.add(result);
		return panel;		
	}

	
	private void initListener() {
		
		buttonLogin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					try {
						if (db_conn.getUser(fieldSearchName.getText())== true) {
						double totalamount = db_conn.getTotalAmount(fieldSearchName.getText());
						user = new User(fieldSearchName.getText(), "M",totalamount);
						panel.setVisible(false);
						try {
							panel = UserFrame();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						panel.setVisible(true);
						add(panel);
						}
						else {
							System.out.println("No such user"+ fieldSearchName.getText());
						}
					} catch (InstantiationException | IllegalAccessException | ClassNotFoundException
							| SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
			}
		});
		
		toMainFrame.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				panel.setVisible(false);
				panel = mainFrame();
				panel.setVisible(true);
				add(panel);
			}
		});
		NewTransaction.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				panel.setVisible(false);
				panel = TransactionFrame();
				panel.setVisible(true);
				add(panel);
			}
		});
		toUserFrame.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				panel.setVisible(false);
				try {
					panel = UserFrame();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				panel.setVisible(true);
				add(panel);
			}
		});
		ShowHistory.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				panel.setVisible(false);
				panel = HistoryFrame();
				panel.setVisible(true);
				add(panel);
			}
		});
		buttonRegister.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				panel.setVisible(false);
				panel = RegisterFrame();
				panel.setVisible(true);
				add(panel);
			}
		});
		SaveUser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				 File file = new File(String.valueOf(fileChooser.getSelectedFile()));
		         try {
					 input = new FileInputStream(file);
				} catch (FileNotFoundException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				user = new User(fieldName.getText(),fieldGender.getText(),0.00);
				try {
					db_conn.addUser(user.getName(), user.getGender(),input);
					panel.setVisible(false);
					try {
						panel = UserFrame();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					panel.setVisible(true);
					add(panel);
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		AddTrans.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String numb = fieldAmount.getText();
				Double doubleN = Double.parseDouble(numb);
				MoneyTransactions newtr = new MoneyTransactions(inputCategory.getText(),String.valueOf(comboBox.getSelectedItem()),doubleN,user);
				String userName = user.getName();
				int ind = 0;
				try {
					ind = db_conn.getIndex(userName);
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					db_conn.addTrans(newtr.getSum(), newtr.getCategory(),ind, newtr.getTransType());
					System.out.println(user.getTotalAmount());
					db_conn.addTotalAmount(user.getTotalAmount(),ind);
					panel.setVisible(false);
					try {
						panel = UserFrame();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					panel.setVisible(true);
					add(panel);
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		btnOpenDir.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				 fileChooser.setDialogTitle("Choose directory");
				 
			        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                            "jpg", "png", "bmp");
                    fileChooser.setFileFilter(filter);
			        int result = fileChooser.showOpenDialog(MoneyFrame.this);
			       
			        if (result == JFileChooser.APPROVE_OPTION )
			                  JOptionPane.showMessageDialog(MoneyFrame.this, 
			                                                fileChooser.getSelectedFile());

			}
		});
		/*
		CalculateCircle.addActionListener(new ActionListener() {
			String type = new String("circle");
			int i = 0;
			@Override
			
			public void actionPerformed(ActionEvent e) {
				Shape c= new Circle("Cruglyak","white",Double.valueOf(field.getText()));
				while (i < shapes.length) {
				    if (shapes[i] == null)
				      {
					shapes[i] = c;
					break;
				      }
				    i++;
			 }
				result.setText(c.toString());
			}
		});
		CalculateRect.addActionListener(new ActionListener() {
			int i = 0;
			String type = new String("rectangle");
			@Override
			public void actionPerformed(ActionEvent e) {
				Shape rect= new Rectangle("Rectangle","red",Double.valueOf(inputSide1.getText()),Double.valueOf(inputSide2.getText()));
			 while (i < shapes.length) {
				    if (shapes[i] == null)
				      {
					shapes[i] = rect;
					break;
				      }
				    i++;
			 }
				result.setText(rect.toString());
			}
		});
		SvLdbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				panel.setVisible(false);
				panel = DatabaseFrame();
				panel.setVisible(true);
				add(panel);
			}
		});
		LoadBase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					result.setText(shape_conn.getShape());
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		SaveBase.addActionListener(new ActionListener() {
			int i = 0;
			@Override
			public void actionPerformed(ActionEvent e) {
				//shape_conn.getShape();
				while(i < shapes.length ) {
				try {
					if(shapes[i]!=null) {
					shape_conn.addShape(shapes[i].getName(), shapes[i].getColor(), "circle",shapes[i].getPerim(), shapes[i].getArea());
					}
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
				i++;
				}
			}
		});
*/
	}
}
