package MoneyManager;
import java.awt.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Statement;
import java.util.ArrayList;

import java.io.InputStream;

import java.sql.PreparedStatement;
public class DBConnector {
	private boolean userExists = false;
	private  FileOutputStream output;
	public File file;
	public static final String SELECT_USER = "SELECT * from users WHERE name = '%s'";
	public static final String SELECT_USERID = "SELECT id from users WHERE name = '%s'";
	public static final String SELECT_HISTORY = "SELECT amount,category,transType from transactions WHERE name_id = %d";
	public static final String INSERT_TRANSACTION = "INSERT INTO transactions (amount,category,name_id,transType) VALUES (%4.2f, '%s', %d, '%s')";
	public static final String INSERT_TOTALAMOUNT = "UPDATE users SET amount = %4.2f  WHERE id = %d";
	public static final String SELECT_USERTOTAL = "SELECT amount from users WHERE name = '%s'";
	public static final String SELECT_USERIMAGE = "SELECT photo from users WHERE name = '%s'";
	public static final String INSERT_USER = "INSERT INTO users (name, gender,photo) VALUES (?,?,?)";
	public ResultSet rs;
	public Connection getConnection() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		 Connection conn = null;
		
		     conn =
		        DriverManager.getConnection("jdbc:mysql://localhost/money_manager?" +
		                                    "user=root&password=");
		 return conn;
	}	
	
	public void addTrans(double amount,String category,int name_id,String trans_type) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		Connection conn = getConnection();
		Statement st = conn.createStatement();
		st.execute(String.format(INSERT_TRANSACTION,amount,category,name_id,trans_type));
		if(st != null) {
			st.close();
		}
		conn.close();
	}
	
	public void addTotalAmount(double amount, int name_id) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		Connection conn = getConnection();
		Statement st = conn.createStatement();
		st.execute(String.format(INSERT_TOTALAMOUNT,amount,name_id));
		if(st != null) {
			st.close();
		}
		conn.close();
	}
	public void addUser(String name,String gender,FileInputStream i) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		Connection conn = getConnection();
		Statement st = conn.createStatement();
		PreparedStatement pstmt = conn.prepareStatement(INSERT_USER);
		pstmt.setBinaryStream(3, i);
        pstmt.setString(1, name);
        pstmt.setString(2, gender);
        System.out.println(i);
        pstmt.executeUpdate();
		//st.execute(String.format(INSERT_USER,name,gender,i));
		if(st != null) {
			st.close();
		}
		conn.close();
	}
	
	public boolean getUser(String name) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		userExists = false;
		Connection conn = getConnection();
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery(String.format(SELECT_USER,name.trim()));
		if(rs.next()) {
			userExists = true;
		}
		if(st != null) {
			st.close();
		}
		
		rs.close();
		conn.close();
		return userExists;
	}
	
	public int getIndex(String name) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		int userId = 0;
		Connection conn = getConnection();
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery(String.format(SELECT_USERID,name.trim()));
		if(rs.next()) {
			userId = rs.getInt("id");
		}
		if(st != null) {
			st.close();
		}
		
		rs.close();
		conn.close();
		return userId;
	}
	
	public ResultSet getHistory(String name) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		//StringBuilder resultText = new StringBuilder();
	    ArrayList<String> transact = new ArrayList<String>();
		Connection conn = getConnection();
		Statement st1 = conn.createStatement();
		ResultSet rs1 = st1.executeQuery(String.format(SELECT_HISTORY,getIndex(name.trim())));
		//String [][] array = new String[rs.last()	][3];
		//while(rs.next()) {
			//transact.add(rs.getString("category"),rs.getString("transType"),String.valueOf(rs.getDouble("amount")));
		//}
		//if(st1 != null) {
			//st1.close();
		//}
		//rs.close();
		//conn.close();
		return rs1;
	}
	
	public double getTotalAmount(String name) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		double userAmount = 0;
		Connection conn = getConnection();
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery(String.format(SELECT_USERTOTAL,name.trim()));
		if(rs.next()) {
			userAmount = rs.getDouble("amount");
		}
		if(st != null) {
			st.close();
		}
		
		rs.close();
		conn.close();
		return userAmount;
	}
	
	public File getImage(String name) throws SQLException, InstantiationException, IllegalAccessException,
			ClassNotFoundException, FileNotFoundException {
		double userAmount = 0;
		Connection conn = getConnection();
		Statement st = conn.createStatement();
		file = new File("Test");
		output = new FileOutputStream(file);
		ResultSet rs = st.executeQuery(String.format(SELECT_USERIMAGE, name.trim()));
		while (rs.next()) {
			InputStream input = rs.getBinaryStream("photo");
			byte[] buffer = new byte[1024];
			try {
				if(input!=null) {
				while (input.read(buffer) > 0) {
					output.write(buffer);
				}}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//if (st != null) {
				//st.close();
			//}
			//System.out.println(file);
		//rs.close();
			//conn.close();
		}
		return file;
	}
}
